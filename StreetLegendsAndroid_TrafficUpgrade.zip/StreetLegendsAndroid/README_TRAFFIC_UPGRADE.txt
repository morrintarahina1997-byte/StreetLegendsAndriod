STREET LEGENDS — TRAFFIC UPGRADE (PHONE-ONLY BUILD)

WHAT'S NEW
- 16 moving traffic cars that travel along the city grid roads.
- 28 pedestrians walking around the city blocks.
- Existing enterable parked cars, missions, enemies, shop, joystick and combat remain.
- Traffic vehicles are ambient traffic and cannot be entered; the five parked vehicles remain enterable.

IMPORTANT: THIS IS A SEPARATE UPGRADE PACKAGE. Keep your existing APK and previous ZIP as backups.

PHONE-ONLY GITHUB ACTIONS STEPS
1. Download this ZIP to your Android phone. Do not overwrite/delete your old project or old ZIP.
2. In your GitHub repository, tap Add file > Upload files and upload this ZIP itself to the repository root. Commit changes.
3. Create a new file at .github/workflows/traffic-upgrade.yml.
4. Paste the workflow contents supplied in the chat. Commit changes.
5. Open Actions and run “Build Street Legends Traffic Upgrade”.
6. When it succeeds, open the run, scroll to Artifacts and download StreetLegends-Traffic-Upgrade-APK.
7. Extract the artifact ZIP and install app-debug.apk. Test moving traffic and pedestrians.

The workflow builds from this ZIP in a temporary folder. It does not replace the existing files in your repository. Keep the old APK in case you want to roll back.
