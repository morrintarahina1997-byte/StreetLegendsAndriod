STREET LEGENDS — PHONE-ONLY APK BUILD

This is the 2D HTML prototype wrapped in a basic Android WebView app. It is not the planned 3D game yet.

PHONE-ONLY BUILD USING GITHUB ACTIONS
1. Download and extract this ZIP on your phone.
2. In your browser, go to https://github.com and create/sign in to an account.
3. Create a NEW repository named StreetLegendsAndroid. For easiest setup, choose Public and do not initialize it with a README.
4. On the repository page, use Add file > Upload files. Upload the CONTENTS of this extracted folder (not the ZIP file itself), including the hidden .github/workflows/android-apk.yml file. If the phone browser does not show hidden files or cannot upload folders, use GitHub's desktop-site option or GitHub's web editor to create .github/workflows/android-apk.yml and paste the workflow contents from this file's matching project file.
5. Commit the uploaded files to the main branch.
6. Open the repository's Actions tab. Choose “Build Street Legends APK”, then “Run workflow” if it has not started automatically.
7. Wait for the workflow to finish with a green check mark. Open that run and scroll to Artifacts. Download “StreetLegends-debug-APK”.
8. Extract the downloaded artifact ZIP; it contains app-debug.apk. Tap the APK to install it. Android may ask you to allow your browser or Files app to install unknown apps; only proceed for a build you requested from your own repository.

If the build fails, open the workflow run and copy the first red error message so it can be troubleshot.
