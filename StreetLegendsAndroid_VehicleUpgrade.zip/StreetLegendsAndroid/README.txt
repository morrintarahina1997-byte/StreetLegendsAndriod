STREET LEGENDS — ANDROID APK STARTER

WHAT THIS IS
This Android Studio project packages the existing Street Legends HTML/JavaScript prototype
inside a simple Android WebView app. It is an APK starter, not a native 3D Unity game.
The current gameplay remains 2D and offline.

REQUIREMENTS
- A computer (Windows, macOS, or Linux)
- Android Studio (stable release)
- Internet on the computer for Android Studio to download build components
- An Android phone and USB cable if you want to install via USB

BUILD THE APK
1. Extract StreetLegendsAndroid.zip to a folder on your computer.
2. Install and open Android Studio.
3. Choose Open, then select the extracted StreetLegendsAndroid folder
   (the folder containing settings.gradle and build.gradle).
4. Wait for Gradle sync to finish. If asked to install Android SDK Platform 35 or
   build tools, accept the recommended installation.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When Android Studio reports success, click Locate.
   The APK should be at app/build/outputs/apk/debug/app-debug.apk.
7. Copy app-debug.apk to your Android phone.
8. Open the APK on your phone and approve "Install unknown apps" for the app you used
   to open it, if Android asks. Only install APKs you built or trust.
9. Launch Street Legends.

INSTALL DIRECTLY OVER USB (OPTIONAL)
1. Enable Developer options on your phone: Settings > About phone > tap Build number
   seven times (wording may differ by device).
2. In Developer options, enable USB debugging.
3. Connect phone to computer and accept the USB debugging prompt.
4. In Android Studio, select your phone in the device list and press Run.

TROUBLESHOOTING
- If Gradle sync fails, check internet and install the SDK version Android Studio requests.
- If the project requests a newer Android Gradle Plugin or SDK, use Android Studio's
  suggested compatible updates.
- This project needs a computer to build. It cannot produce an APK directly on an Android
  phone using Android Studio.
- The app is fullscreen landscape and has no network permissions because this prototype
  runs locally.
- Online multiplayer, native 3D, and an APK store release are not included yet.
